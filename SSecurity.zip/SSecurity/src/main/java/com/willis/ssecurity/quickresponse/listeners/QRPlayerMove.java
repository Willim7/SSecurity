package com.willis.ssecurity.quickresponse.listeners;

import com.willis.ssecurity.SSecurity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class QRPlayerMove implements Listener {

    SSecurity plugin;

    public QRPlayerMove(SSecurity plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {

        Player player =  event.getPlayer();

        if (plugin.geteInput().contains(player.getUniqueId()) || (plugin.getgLogin().contains(player.getUniqueId()) || (plugin.geteLogin().containsKey(player.getUniqueId())))) {
            event.setTo(event.getFrom());
        }
    }
}
